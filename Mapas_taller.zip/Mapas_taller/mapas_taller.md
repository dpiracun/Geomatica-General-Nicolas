---
title: "Taller de Google Earth Engine: mapas, tablas y análisis"
author: "Damian  Nicolas Piracun Farfan"
date: 20-05-2026
format:
  html:
    toc: true
    toc-depth: 3
    number-sections: true
    theme: cosmo
  pdf:
    toc: true
    number-sections: true
editor: visual
---

# Introducción

El presente reporte consolida los productos gráficos y tabulares generados en el taller de Google Earth Engine —GEE—, incluyendo mapas, tablas de apoyo, evidencias del procedimiento y el análisis conceptual relacionado con la arquitectura cliente-servidor, las firmas espectrales y el repositorio de control de versiones.

# Mapas generados

A continuación se presentan los mapas obtenidos durante el procesamiento y visualización en Google Earth Engine.

::: {.columns}
::: {.column width="50%"}
![Mapa 1](mapa1.jpeg)
:::

::: {.column width="50%"}
![Mapa 2](mapa2.jpeg)
:::
:::

::: {.columns}
::: {.column width="50%"}
![Mapa 3](mapa3.jpeg)
:::

::: {.column width="50%"}
![Mapa 4](mapa4.jpeg)
:::
:::

::: {.columns}
::: {.column width="50%"}
![Mapa 5](mapa5.jpeg)
:::

::: {.column width="50%"}
![Mapa 6](mapa6.jpeg)
:::
:::

![Mapa 7](mapa7.jpeg)

# Tablas de resultados

Las siguientes tablas sintetizan los datos obtenidos durante el desarrollo del taller.

::: {.columns}
::: {.column width="50%"}
![Tabla 1](tabla1.jpeg)
:::

::: {.column width="50%"}
![Tabla 2](tabla2.jpeg)
:::
:::

# Proceso metodológico

En este apartado se documentan las evidencias del procedimiento realizado en el entorno de trabajo.

::: {.columns}
::: {.column width="50%"}
![Proceso 1](proceso1%20(1).jpeg)
:::

::: {.column width="50%"}
![Proceso 2](proceso2.jpeg)
:::
:::

# Desarrollo conceptual

## Arquitectura cliente-servidor en Google Earth Engine

Google Earth Engine funciona mediante una arquitectura cliente-servidor. Esto significa que existe una diferencia estructural entre los objetos que se crean y manipulan localmente en el cliente, como el navegador web o el entorno de programación, y los objetos que realmente se procesan en los servidores de Google.

Los objetos cliente corresponden a elementos nativos del lenguaje utilizado, por ejemplo listas, diccionarios, cadenas de texto o números propios de JavaScript o Python. Estos objetos existen en el entorno local y no tienen por sí mismos capacidad para ejecutar operaciones espaciales sobre imágenes satelitales, colecciones ráster o geometrías almacenadas en la nube.

En cambio, los objetos servidor son estructuras propias de Earth Engine, como `ee.Image`, `ee.ImageCollection`, `ee.Feature`, `ee.FeatureCollection`, `ee.Geometry`, `ee.List` o `ee.Dictionary`. Estos objetos no contienen directamente los datos en el computador del usuario, sino una referencia a operaciones que serán ejecutadas en la infraestructura de nube de Google Earth Engine.

Por esta razón, declarar variables nativas, como una lista común de Python o JavaScript, resulta incompatible con métodos espaciales de GEE cuando se requiere procesar catálogos ráster sobre el territorio colombiano. Por ejemplo, una lista nativa no puede aplicar filtros espaciales, temporales o espectrales sobre una colección Sentinel, Landsat o MODIS. Para realizar este tipo de operaciones se deben utilizar objetos de servidor, debido a que los métodos como `.filterBounds()`, `.filterDate()`, `.map()`, `.select()` o `.reduceRegion()` pertenecen al modelo computacional de Earth Engine.

El método `.getInfo()` cumple una función analítica estricta: trasladar un resultado desde el servidor hacia el cliente. Es decir, permite consultar valores ya calculados por Earth Engine y traerlos al entorno local para inspección, impresión o validación puntual. Sin embargo, no debe utilizarse como método principal de procesamiento, porque rompe la lógica de cómputo distribuido, puede ralentizar el flujo de trabajo y generar errores cuando se intenta descargar demasiada información desde el servidor.

## Firmas espectrales y comportamiento radiométrico

La resolución espectral es fundamental para discriminar coberturas terrestres complejas, ya que permite identificar cómo diferentes superficies reflejan o absorben la energía electromagnética en distintas regiones del espectro. No todas las coberturas responden igual ante la radiación solar: el agua, la vegetación, los suelos desnudos, las áreas urbanas y las zonas agrícolas tienen comportamientos radiométricos diferentes.

En el caso de un cuerpo de agua, como el Embalse de Tominé, la reflectancia suele ser baja en el infrarrojo cercano —NIR— y en el infrarrojo de onda corta —SWIR—. Esto ocurre porque el agua absorbe gran parte de la radiación en estas longitudes de onda. Por tanto, en bandas NIR y SWIR, los cuerpos de agua tienden a observarse oscuros o con valores bajos de reflectancia.

Por el contrario, un parche de bosque altoandino presenta una respuesta espectral diferente. La vegetación sana refleja fuertemente en el infrarrojo cercano debido a la estructura interna de las hojas, especialmente por la interacción de la radiación con el mesófilo foliar. En el visible, la vegetación absorbe principalmente en el rojo y el azul por acción de los pigmentos fotosintéticos, mientras que refleja más en el verde. En el SWIR, la respuesta está relacionada con el contenido de humedad de la vegetación: a mayor contenido de agua en las hojas, mayor absorción y menor reflectancia.

Esta diferencia en la huella espectral permite separar automáticamente coberturas como agua y bosque mediante algoritmos de clasificación supervisada, no supervisada o índices espectrales. En términos prácticos, el agua presenta baja reflectancia en NIR y SWIR, mientras que la vegetación presenta alta reflectancia en NIR y una respuesta variable en SWIR según su humedad. Esta separación espectral permite clasificar el paisaje, identificar coberturas y analizar cambios territoriales mediante imágenes satelitales.

